package com.example.akash_word_searcher

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
