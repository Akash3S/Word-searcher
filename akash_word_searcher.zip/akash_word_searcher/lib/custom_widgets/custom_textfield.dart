import 'package:akash_word_searcher/viewmodel/app_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:get/get.dart';

class CustomTextField extends StatelessWidget {
  CustomTextField({super.key});

  AppViewModel model = Get.find();
  TextEditingController textEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AppViewModel>(
      builder: (controller) {
    
        return SizedBox(
          width: 80.0,
          height: 60.0,
          child: TextFormField(
            textAlign: TextAlign.center,
            controller: textEditingController,
            // onChanged: (value) {
            enabled: model.enableTextField.value,
            // },
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(8.0)),
                borderSide: BorderSide(
                  color: Colors.grey,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
