import 'package:akash_word_searcher/screens/grid_creator_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:get/get.dart';

class RowsAndColumnSelector extends StatelessWidget {
  RowsAndColumnSelector({super.key});
  TextEditingController rowsController = TextEditingController();
  TextEditingController columnsController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text("Word Search"),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 60.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Text(
                "Enter no. of Rows",
                style: TextStyle(fontSize: 20.0),
              ),
              SizedBox(
                height: 60,
              ),
              TextField(
                  controller: rowsController,
                  keyboardType: TextInputType.number),
              SizedBox(
                height: 60,
              ),
              Text(
                "Enter no. of Columns",
                style: TextStyle(fontSize: 20.0),
              ),
              SizedBox(
                height: 60,
              ),
              TextField(
                  controller: columnsController,
                  keyboardType: TextInputType.number),
              SizedBox(
                height: 60,
              ),
              SizedBox(
                  width: 300.0,
                  height: 60.0,
                  child: ElevatedButton(
                      onPressed: () {
                        Get.to(() => GridCreatorScreen(
                              numberOfRows: int.parse(rowsController.text),
                              numberOfColumn: int.parse(columnsController.text),
                            ));
                      },
                      child: Text(
                        "Next",
                        style: TextStyle(fontSize: 20),
                      )))
            ],
          ),
        ),
      ),
    );
  }
}
