import 'package:akash_word_searcher/custom_widgets/custom_textfield.dart';
import 'package:akash_word_searcher/screens/rows_and_columns_selector.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class AppViewModel extends GetxController {
  List<Widget> textFieldinRow = <Widget>[];
  List<Widget> listOfRows = <Widget>[];
  RxBool enableTextField = true.obs;
  TextEditingController searchedTextController = TextEditingController();

  disableTextField() {
    enableTextField.value = false;
    update();
  }

  updateUIOnChange() {
    update();
  }

  autoMoveToNextPage() {
    Future.delayed(const Duration(seconds: 5), () {
      Get.to(() => RowsAndColumnSelector());
    });
  }

  Row addTextFieldToRows(
      {required int numberOfTextFields, required Widget widgetToAdd}) {
    textFieldinRow.clear();
    for (int i = 0; i < numberOfTextFields; i++) {
      textFieldinRow.add(widgetToAdd);
    }

// for (int i = 0; i < numberOfTextFields; i++) {
//       listOfRows.add(textFieldinRow);
//     }

    return Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: textFieldinRow);
  }

  List<Widget> addRowsToColumn(
      {required int numberOfTextFields, required int numberOfRows}) {
    listOfRows.clear();
    for (int i = 0; i < numberOfRows; i++) {
      listOfRows.add(addTextFieldToRows(
          numberOfTextFields: numberOfTextFields,
          widgetToAdd: CustomTextField()));
    }
    return listOfRows;
  }
}
